package org.gdal.gdal;

public class IndexColorModel {

}
